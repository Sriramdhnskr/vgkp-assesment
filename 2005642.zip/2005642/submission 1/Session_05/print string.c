#include<stdio.h>
int main()
{
    char s[100];
    scanf("%s",s);
    printf("%s",s);
    return 0;
}
