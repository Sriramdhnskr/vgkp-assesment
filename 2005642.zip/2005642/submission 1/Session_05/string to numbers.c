#include<stdio.h>
int main()
{
    char s[100];
    int x;
    scanf("%s",s);
    x=atoi(s);
    printf("%d",x);
}
